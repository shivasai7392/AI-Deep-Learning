# Memotrek

recommend future travel destinations using neural network image classfication and natural language processing
